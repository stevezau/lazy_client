<head>
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.2/jquery.mobile-1.3.2.min.css" />
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.3.2/jquery.mobile-1.3.2.min.js"></script>
</head>

<body>
<!-- Home -->
<div data-role="page" id="page1">
    <div data-theme="b" data-role="header">
        <h1>
            Media Manager
        </h1>
        <div data-role="navbar" data-iconpos="top">
            <ul>
                <li>
                    <a href="#page1" data-transition="fade" data-theme="" data-icon="" class="ui-btn-active ui-state-persist">
                        Home
                    </a>
                </li>
                <li>
                    <a href="#page1" data-transition="fade" data-theme="" data-icon="">
                        Downloads
                    </a>
                </li>
                <li>
                    <a href="#page1" data-transition="fade" data-theme="" data-icon="">
                        Other
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div data-role="content">
    </div>
</div>
</body>