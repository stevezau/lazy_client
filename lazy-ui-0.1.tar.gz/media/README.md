Lazy-UI Installation
====




TODO: FIXXXXXXXXXXXXXXXX THISSSSSSSSSSSSSSS

The following packages need to be installed

sudo apt-get install apache2 php

install pear
install config_lite from pear
install sqlite and php
install suphp and fix config files
install php5-curl
